package com.example.string_color_graphock_resources

val truthQuestions: Array<String> = arrayOf(
    "       Nice!\n" +
            "You choice truth and you should get answer \nfor this question: \n\n" +
            "Who is sitting on your right?",
    "       Nice!\n" +
            "You choice truth and you should get answer \nfor this question: \n\n" +
            "Who is sitting on your left?",
    "       Nice!\n" +
            "You choice truth and you should get answer \nfor this question: \n\n" +
            "How old are you?",
    "       Nice!\n" +
            "You choice truth and you should get answer \nfor this question: \n\n" +
            "What you have eat today?",
    "       Nice!\n" +
            "You choice truth and you should get answer \nfor this question: \n\n" +
            "Do you like ferrari?"
)