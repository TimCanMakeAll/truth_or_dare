package com.example.string_color_graphock_resources

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class Menu : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        val startButton = findViewById<Button>(R.id.StartButton)

        startButton.setOnClickListener {

            val enteredName1 = findViewById<EditText>(R.id.editText1).text.toString()
            val enteredName2 = findViewById<EditText>(R.id.editText2).text.toString()
            val enteredName3 = findViewById<EditText>(R.id.editText3).text.toString()
            val enteredName4 = findViewById<EditText>(R.id.editText4).text.toString()
            val enteredName5 = findViewById<EditText>(R.id.editText5).text.toString()
            val enteredName6 = findViewById<EditText>(R.id.editText6).text.toString()

            if (enteredName1 == "" || enteredName2 == "" || enteredName3 == "" ||
                enteredName4 == "" || enteredName5 == "" || enteredName6 == ""){

                Toast.makeText(this, "Enter minimum 1 name of player!", Toast.LENGTH_SHORT)
                    .show()
            } else {

                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
        }
    }
}

