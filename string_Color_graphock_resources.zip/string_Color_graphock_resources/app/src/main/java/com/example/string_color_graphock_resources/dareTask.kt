package com.example.string_color_graphock_resources

val dareTask: Array<String> = arrayOf(
    "       Nice!\n" +
            "You choice dare and you should complete \nyour task: \n\n" +
            "Eat something",
    "       Nice!\n" +
            "You choice dare and you should complete \nyour task: \n\n" +
            "Fly as a bird",
    "       Nice!\n" +
            "You choice dare and you should complete \nyour task: \n\n" +
            "Jump as a frog",
    "       Nice!\n" +
            "You choice dare and you should complete \nyour task: \n\n" +
            "Go to the kitchen",
    "       Nice!\n" +
            "You choice dare and you should complete \nyour task: \n\n" +
            "By ferrari"
)