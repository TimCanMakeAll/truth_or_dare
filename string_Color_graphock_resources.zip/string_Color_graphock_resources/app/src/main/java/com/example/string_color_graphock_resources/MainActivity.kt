package com.example.string_color_graphock_resources

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var textView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView = findViewById(R.id.play_card_window_text)
    }

    fun truthClicker(view: View) {

        textView.text = truthQuestions[(0..4).random()]
    }

    fun randomClicker(view: View) {

        if ((0..1).random() == 0) {

            textView.text = truthQuestions[(0..4).random()]
        } else {
            textView.text = dareTask[(0..4).random()]
        }
    }

    fun dareTask(view: View) {

        textView.text = dareTask[(0..4).random()]
    }
}